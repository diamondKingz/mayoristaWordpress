<?php

/** 
 *FullTimeForce
 *@link 
 *@package WordPress
 *@subpackage FullTimeForce
 *@since 1.0.0
 *@version 1.0.0
 */

define('URL', get_stylesheet_directory_uri());
define('IMG', URL . '/images');
define('JS', URL . '/libraries/js');
define('CSS', URL . '/libraries/css');
define('LANG', get_bloginfo("language"));
define('NONE', false);

if (!function_exists('general_scripts')):
    function general_scripts()
    {
        // STYLES -------------------------------
        wp_enqueue_style('style', get_stylesheet_uri(), array(), '1.0.0', 'all');
        wp_enqueue_style('maincss', get_template_directory_uri() . '/public/css/app.css', '1.0.0', 'all');

        // SCRIPTS -------------------------------
        wp_enqueue_script('mainjs', get_template_directory_uri() . '/public/js/main.min.js', array(), '1.0.0', true);

        // if (is_page('preguntas-frecuentes') || is_page('faq') || is_page('perguntas-frequentes') || is_product()) {
        wp_enqueue_script('accordionjs', JS . '/accordion.min.js', array('jquery'), '1.0.0', true);
        // }
    }
endif;
add_action('wp_enqueue_scripts', 'general_scripts');

//widgets
function mi_tema_widgets_init()
{
    register_sidebar(array(
        'name'          => 'Sidebar principal',
        'id'            => 'sidebar-principal',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'mi_tema_widgets_init');

//add postthumbnail function
if (function_exists('add_theme_support'))
    add_theme_support('post-thumbnails');

//excerpt 30 word
function my_excerpt_length($length)
{
    return 30;
}
add_filter('excerpt_length', 'my_excerpt_length');

//registrar menus
function register_my_menus()
{
    register_nav_menus(
        array(
            'header-menu' => __('In header -')
        )
    );
}
add_action('init', 'register_my_menus');

//modulo de redes - get option
require_once get_template_directory() . '/inc/modules/module_information.php';
// require_once get_template_directory().'/inc/tax_services.php';

function wp_translate($br, $us, $en)
{
    if (LANG == 'pt-BR') {
        echo $br;
    } elseif (LANG == 'en-US') {
        echo $us;
    } else {
        echo $en;
    }
}



// -----------------------------------------------------
// -----------------------------------------------------

function register_product_collections_taxonomy()
{
    $labels = array(
        'name'              => _x('Collections', 'taxonomy general name', 'textdomain'),
        'singular_name'     => _x('Collection', 'taxonomy singular name', 'textdomain'),
        'search_items'      => __('Search Collections', 'textdomain'),
        'all_items'         => __('All Collections', 'textdomain'),
        'parent_item'       => __('Parent Collection', 'textdomain'),
        'parent_item_colon' => __('Parent Collection:', 'textdomain'),
        'edit_item'         => __('Edit Collection', 'textdomain'),
        'update_item'       => __('Update Collection', 'textdomain'),
        'add_new_item'      => __('Add New Collection', 'textdomain'),
        'new_item_name'     => __('New Collection Name', 'textdomain'),
        'menu_name'         => __('Collections', 'textdomain'),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'collection'),
    );

    register_taxonomy('product_collection', array('product'), $args);
}
add_action('init', 'register_product_collections_taxonomy');

function register_product_metal_taxonomy()
{
    $labels = array(
        'name'              => _x('Metals', 'taxonomy general name', 'textdomain'),
        'singular_name'     => _x('Metal', 'taxonomy singular name', 'textdomain'),
        'search_items'      => __('Search Metals', 'textdomain'),
        'all_items'         => __('All Metals', 'textdomain'),
        'parent_item'       => __('Parent Metal', 'textdomain'),
        'parent_item_colon' => __('Parent Metal:', 'textdomain'),
        'edit_item'         => __('Edit Metal', 'textdomain'),
        'update_item'       => __('Update Metal', 'textdomain'),
        'add_new_item'      => __('Add New Metal', 'textdomain'),
        'new_item_name'     => __('New Metal Name', 'textdomain'),
        'menu_name'         => __('Metals', 'textdomain'),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'metal'),
    );

    register_taxonomy('product_metal', array('product'), $args);
}
add_action('init', 'register_product_metal_taxonomy');

function register_product_for_whom_taxonomy()
{
    $labels = array(
        'name'              => _x('For Whom', 'taxonomy general name', 'textdomain'),
        'singular_name'     => _x('For Whom', 'taxonomy singular name', 'textdomain'),
        'search_items'      => __('Search For Whom', 'textdomain'),
        'all_items'         => __('All For Whom', 'textdomain'),
        'parent_item'       => __('Parent For Whom', 'textdomain'),
        'parent_item_colon' => __('Parent For Whom:', 'textdomain'),
        'edit_item'         => __('Edit For Whom', 'textdomain'),
        'update_item'       => __('Update For Whom', 'textdomain'),
        'add_new_item'      => __('Add New For Whom', 'textdomain'),
        'new_item_name'     => __('New For Whom Name', 'textdomain'),
        'menu_name'         => __('For Whom', 'textdomain'),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'for-whom'),
    );

    register_taxonomy('product_for_whom', array('product'), $args);
}
add_action('init', 'register_product_for_whom_taxonomy');

// -----------------------------------------------------
// -----------------------------------------------------


function listar_terminos_de_taxonomia($taxonomia_slug, $parent = 0)
{
    $terms = get_terms(array(
        'taxonomy'   => $taxonomia_slug,
        'hide_empty' => false,
        'parent'     => $parent,
    ));

    if (!empty($terms) && !is_wp_error($terms)) {
        echo '<ul>';
        foreach ($terms as $term) {
            $term_link = get_term_link($term);
            echo '<li>
                <a href="' . esc_url($term_link) . '">
                    ' . esc_html($term->name) . '
                </a>';

            // Verifica si este término tiene hijos
            $child_terms = get_terms(array(
                'taxonomy'   => $taxonomia_slug,
                'hide_empty' => false,
                'parent'     => $term->term_id,
            ));

            if (!empty($child_terms)) {
                // Llamada recursiva para mostrar los hijos
                listar_terminos_de_taxonomia($taxonomia_slug, $term->term_id);
            }

            echo '</li>';
        }
        echo '</ul>';
    }
}

function get_filter()
{
    echo '<div class="catalog_filter">
        <div class="container">
            <button type="button" class="all_filters toggle_popup" data-id="popup_filter">
                <svg class="svg__allFiltersIcon"><use xlink:href="#allFiltersIcon"></use></svg>';
    wp_translate('Todos os filtros', 'All filters', 'Todos los filtros');
    echo '</button>
        </div>
    </div>';

    echo '<div class="popup popup_filter" id="popup_filter">
        <div class="popup__bg toggle_popup"></div>
        <div class="popup__box">
            <div class="popup_filter-schema">
                <div class="popup_filter-head">
                    <h2>';
    wp_translate('Filtros', 'Filters', 'Filtros');
    echo '  </h2>
                    <button type="button" class="toggle_popup">
                        <svg class="dagger-close"><use xlink:href="#dagger-close"></use></svg>
                    </button>
                </div>
                <div class="popup_filter-body accordionjs" id="my-accordion">';
    if (is_active_sidebar('sidebar-principal') && is_product_category()) {
        echo '<li class="filter__modal"><div>
            <p>';
        wp_translate('Preço', 'Price', 'Precio');
        echo '</p>
                                <svg class="svg__expandMore"><use xlink:href="#expandMore"></use></svg>
                            </div>
                            <div>';
        dynamic_sidebar('sidebar-principal');
        echo '</div></li>';
    }
    echo '<li class="filter__modal">
                        <div>
                            <p>';
    wp_translate('A promoção', 'The promotion', 'La promoción');
    echo '</p>
                            <svg class="svg__expandMore"><use xlink:href="#expandMore"></use></svg>
                        </div>
                        <div>';
    listar_terminos_de_taxonomia('product_collection');
    echo '</div>
                    </li>
                    <li class="filter__modal">
                        <div>
                            <p>';
    wp_translate('Categoria', 'Category', 'Categoría');
    echo '</p>
                            <svg class="svg__expandMore"><use xlink:href="#expandMore"></use></svg>
                        </div>
                        <div>';
    listar_terminos_de_taxonomia('product_cat');
    echo '</div>
                    </li>
                    <li class="filter__modal">
                        <div>
                            <p>';
    wp_translate('O metal', 'The metal', 'El metal');
    echo '</p>
                            <svg class="svg__expandMore"><use xlink:href="#expandMore"></use></svg>
                        </div>
                        <div>';
    listar_terminos_de_taxonomia('product_metal');
    echo '</div>
                    </li>
                    <li class="filter__modal">
                        <div>
                            <p>';
    wp_translate('Para quem', 'For whom', 'Para quien');
    echo '</p>
                            <svg class="svg__expandMore"><use xlink:href="#expandMore"></use></svg>
                        </div>
                        <div>';
    listar_terminos_de_taxonomia('product_for_whom');
    echo '</div>
                    </li>
                </div>
            </div>
        </div>
    </div>';
}

function get_card_product($product_id)
{
    $product = wc_get_product($product_id);

    if (!$product) return;

    // Obtener imagen destacada o imagen placeholder de WooCommerce
    $image_url = get_the_post_thumbnail_url($product_id, 'medium');
    if (!$image_url) {
        $image_url = wc_placeholder_img_src(); // Imagen por defecto de WooCommerce
    }

    echo '<div class="product_card">
        <div class="product_card-top">
            <span>New</span>
            <a class="product_card-image" href="' . esc_url(get_permalink($product_id)) . '">
                <img src="' . esc_url($image_url) . '" alt="' . esc_attr($product->get_name()) . '" loading="lazy">
            </a>
        </div>
        <div class="product_card-info">
            <p>02-5563-00-401-1110</p>
            <p>La masa 4.69 g</p>
            <div class="product_card-buttons">
                <div class="product_card-add_to_basket">' . do_shortcode('[yith_wcwl_add_to_wishlist]') . '</div>
                <a href="' . esc_url(get_permalink($product_id)) . '" class="product_card-eye">
                    <svg class="MuiSvgIcon-root">
                        <use xlink:href="#quick-view"></use>
                    </svg>
                </a>
            </div>
        </div>
    </div>';
}
