<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>

    <?php if (is_404()): ?>
        <title><?php esc_attr_e("Error Page - 404"); ?></title>
    <?php else: ?>
        <title><?php echo wp_get_document_title(); ?></title>
    <?php endif; ?>

</head>

<body <?php body_class(); ?>>

    <header class="header">
        <div class="header_top w-100">
            <div class="container">
                <marquee behavior="scroll" direction="left">
                    Los actuales DESCUENTOS: массовка hasta 420 ₽, con las piedras naturales de hasta 370 ₽, de la cadena de hasta 750 ₽. La compra del metal 999,9 con el iva - 9680 ₽/g
                </marquee>
            </div>
        </div>
        <div class="header_info">
            <div class="container">
                <?php if (!empty(get_option('nro_1'))): ?>
                    <a href="tel:<?php echo get_option('nro_1'); ?>">
                        <?php echo get_option('nro_1'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="headerBox">
            <div class="container">
                <div class="headerBox__item">
                    <a href="<?php echo esc_url(home_url('/')) ?>" class="headerBox__logo">
                        <img src="<?php echo IMG; ?>/logo.webp" />
                    </a>
                    <div class="headerBox__catalog">
                        <button type="button" class="toggle_menu">
                            <svg class="svg__headerCatalogButton">
                                <use xlink:href="#headerCatalogButton"></use>
                            </svg>
                            <svg class="svg__headerCatalogButtonClose">
                                <use xlink:href="#dagger-close"></use>
                            </svg>
                            <p><?php wp_translate('Diretório', 'Catalog', 'Directorio') ?></p>
                        </button>
                    </div>
                    <div class="headerBox__searchingForm">
                        <?php get_search_form(); ?>
                    </div>
                    <div class="headerBox__icons">
                        <?php if (NONE): ?>
                            <button type="button">
                                <svg class="svg__profile">
                                    <use xlink:href="#profile"></use>
                                </svg>
                            </button>
                            <a href="<?php echo esc_url(home_url('wishlist')); ?>" class="favorites">
                                <svg class="svg__heart">
                                    <use xlink:href="#heart-header"></use>
                                </svg>
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo esc_url(home_url('basket')); ?>" class="basket">
                            <svg class="svg__basket">
                                <use xlink:href="#headerBasket"></use>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <?php get_template_part('inc/sections/menu'); ?>
        </div>
    </header>

    <nav>
        <?php wp_nav_menu(array('theme_location' => 'header-menu', 'menu_class' => 'container')); ?>
    </nav>