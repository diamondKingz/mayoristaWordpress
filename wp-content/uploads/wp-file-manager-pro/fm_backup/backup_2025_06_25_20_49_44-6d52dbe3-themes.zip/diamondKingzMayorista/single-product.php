<?php
/*
    Template name: catalog
*/

get_header();

global $product;

if (! is_a($product, 'WC_Product')) {
    $product = wc_get_product(get_the_ID());
}

$product_id = get_the_ID();

?>

<style>
    html {
        scroll-behavior: smooth;
    }
</style>

<section class="sp_product">
    <div class="container">
        <div class="sp_product-grid">
            <div class="sp_product-col">
                <div class="breadcrumb">
                    <ol>
                        <li>
                            <a href="<?php echo esc_url(home_url('/')) ?>"><?php wp_translate('Lar', 'Home', 'Inicio'); ?></a>
                        </li>
                        <li>/</li>
                        <li><?php echo get_the_title(); ?></li>
                    </ol>
                </div>
                <h1><?php echo get_the_title(); ?></h1>
                <div class="sp_product-actions flex">
                    <a class="to_deco" href="#<?php wp_translate('decoração', 'decoration', 'decoracion'); ?>">
                        <svg class="svg__aboutDecoration">
                            <use xlink:href="#aboutDecoration"></use>
                        </svg>
                        <?php wp_translate('Sobre decoração', 'About decoration', 'Sobre la decoración'); ?>
                    </a>
                </div>
                <div class="sp_product--price">
                    <p class="label"><?php wp_translate('O preço do produto', 'The price for the product', 'El precio por el producto'); ?></p>
                    <p class="price"><?php echo $product->get_price_html(); ?></p>

                    <?php if (!empty(get_field('price_per_gram'))): ?>
                        <div class="sp_product--recomendation">
                            <p class="label">
                                <?php wp_translate('Preço de varejo recomendado por grama', 'Recommended retail price per gram', 'Precio de venta recomendado por gramo'); ?>
                                <svg class="svg__warningInfo"><use xlink:href="#warningInfo"></use></svg>
                            </p>
                            <p class="price-recomendation">$ <?php echo get_field('price_per_gram') ?></p>
                        </div>
                    <?php endif; ?>

                </div>
                <?php echo do_shortcode('[yith_wcwl_add_to_wishlist product_id="' . get_the_ID() . '"]'); ?>
            </div>
            <div class="sp_product-col">
                <div class="splide" role="group" id="gallery">
                    <div class="splide__track">
                        <ul class="splide__list">
                            <?php
                            // Obtener la imagen destacada del producto
                            $product = wc_get_product(get_the_ID());
                            $featured_image = get_the_post_thumbnail_url($product->get_id(), 'full');

                            if ($featured_image) {
                                echo '<li class="splide__slide"><img src="' . esc_url($featured_image) . '" alt="Imagen destacada"></li>';
                            }

                            // Obtener las imágenes de la galería del producto
                            $gallery_images = $product->get_gallery_image_ids();

                            foreach ($gallery_images as $image_id) {
                                $image_url = wp_get_attachment_url($image_id);
                                if ($image_url) {
                                    echo '<li class="splide__slide"><img src="' . esc_url($image_url) . '" alt="Imagen de la galería"></li>';
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="about_deco" id="<?php wp_translate('decoração', 'decoration', 'decoracion'); ?>">
    <div class="container">
        <h2><?php wp_translate('Sobre decoração', 'About decoration', 'Sobre la decoración') ?></h2>
        <div class="about_deco-flex">
            <?php if (have_rows('features') || !empty(get_option('whatsapp')) || !empty(get_option('nro_1'))): ?>
                <div class="product-info product-info_detail">
                    <?php if (have_rows('features')): ?>
                        <?php while (have_rows('features')): the_row(); ?>
                            <div class="product-info__item">
                                <span class="left"><?php echo get_sub_field('label') ?? '' ?></span>
                                <span class="right"><?php echo get_sub_field('value') ?? '' ?></span>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>

                    <?php if (!empty(get_option('whatsapp')) || !empty(get_option('nro_1'))): ?>
                        <div class="phone-box phone-box_product">
                            <div class="phone-box__questions">
                                <h3>¿Tiene alguna pregunta?</h3>
                                <p>Póngase en contacto con nosotros</p>
                            </div>
                            <?php if (!empty(get_option('nro_1'))): ?>
                                <div class="phone-box__number">
                                    <a href="tel:<?php echo get_option('nro_1'); ?>">
                                        <?php echo get_option('nro_1'); ?>
                                    </a>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty(get_option('whatsapp'))): ?>
                                <div class="phone-box__message">
                                    <a href="<?php echo get_option('whatsapp') ?>" target="_blank">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                            <path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7 .9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z" />
                                        </svg>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty(get_field('more_information')) || !empty(get_field('the_delivery_of')) || trim(get_the_content()) != ''): ?>
                <div>
                    <ul id="my-accordion" class="accordionjs faq_list">
                        <?php if (trim(get_the_content()) != ''): ?>
                            <li class="faq__item">
                                <div>
                                    <p><?php wp_translate('Descrição do produto', 'Product description', 'Descripción del producto'); ?></p>
                                </div>
                                <div>
                                    <?php the_content(); ?>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (!empty(get_field('more_information'))): ?>
                            <li class="faq__item">
                                <div>
                                    <p><?php wp_translate('Mais informações', 'More information', 'Más información') ?></p>
                                </div>
                                <div>
                                    <p><?php echo get_field('more_information') ?? ''; ?></p>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (!empty(get_field('the_delivery_of'))): ?>
                            <li class="faq__item">
                                <div>
                                    <p><?php wp_translate('A entrega de', 'The delivery of', 'La entrega de') ?></p>
                                </div>
                                <div>
                                    <p><?php echo get_field('the_delivery_of') ?? ''; ?></p>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>

<?php get_template_part('inc/sections/sec_news'); ?>

<?php get_footer(); ?>

<script>
    jQuery(document).ready(function($) {
        $("#my-accordion").accordionjs({
            closeAble: true,
            closeOther: true,
            slideSpeed: 150,
            activeIndex: 100,
            openSection: function(section) {},
            beforeOpenSection: function(section) {},
        });
    });
</script>