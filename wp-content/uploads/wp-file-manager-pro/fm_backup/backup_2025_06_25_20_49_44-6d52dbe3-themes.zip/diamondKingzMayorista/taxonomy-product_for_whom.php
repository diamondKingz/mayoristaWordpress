<?php

get_header();

$paged = get_query_var('paged') ? get_query_var('paged') : 1;

$term = get_queried_object();

$args = array(
    'post_type'      => 'product',
    'post_status'    => 'publish',
    'posts_per_page' => 20,
    'orderby'        => 'date',
    'order'          => 'DESC',
    'paged'          => $paged,
    'tax_query'      => array(
        array(
            'taxonomy' => 'product_for_whom',
            'field'    => 'slug',
            'terms'    => $term->slug,
        ),
    ),
);

$query = new WP_Query($args);
?>

<section class="catalog">
    <div class="container">
        <div class="breadcrumb">
            <ol>
                <li>
                    <a href="<?php echo esc_url(home_url('/')) ?>"><?php wp_translate('Lar', 'Home', 'Inicio'); ?></a>
                </li>
                <li>/</li>
                <li><?php echo esc_html($term->name); ?></li>
            </ol>
        </div>
        <div class="w-100 catalog_head">
            <h1><?php echo esc_html($term->name); ?></h1>
        </div>
    </div>
    <?php get_filter(); ?>
    <div class="container">
        <?php if ($query->have_posts()) : ?>
            <div class="catalog_body w-100">
                <div class="catalog_grid">
                    <?php
                    while ($query->have_posts()) {
                        $query->the_post();
                        get_card_product(get_the_ID());
                    }
                    ?>
                    <?php wp_reset_postdata(); ?>
                </div>
                <?php if ($query->max_num_pages > 19) : ?>
                    <div class="catalog_pagination">
                        <?php
                        echo paginate_links(array(
                            'total'     => $query->max_num_pages,
                            'current'   => $paged,
                            'format'    => '?paged=%#%',
                            'prev_text' => __('«'),
                            'next_text' => __('»'),
                        ));
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php else : ?>
            <div class="catalog_grid">
                <div class="catalog_empty">
                    <p><?php wp_translate('Não há produtos disponíveis.', 'There are no products available.', 'No hay productos disponibles.') ?></p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>

<script>
    jQuery(document).ready(function($) {
        $("#my-accordion").accordionjs({
            closeAble: true,
            closeOther: true,
            slideSpeed: 150,
            activeIndex: 100,
            openSection: function(section) {},
            beforeOpenSection: function(section) {},
        });
    });
</script>