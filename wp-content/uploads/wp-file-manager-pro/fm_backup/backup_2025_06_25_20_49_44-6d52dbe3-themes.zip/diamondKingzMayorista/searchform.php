<form role="search" method="get" class="formSearchWrapper" action="<?php echo home_url('/'); ?>">
    <div class="formSearchWrapper__field">
        <input type="search" class="search-field" placeholder="Buscar" value="<?php echo get_search_query() ?>" name="s" />
    </div>
    <div class="formSearchWrapper__button">
        <button type="submit" class="search-submit">
            <svg class="svg__searchPage">
                <use xlink:href="#search"></use>
            </svg>
        </button>
    </div>
</form>