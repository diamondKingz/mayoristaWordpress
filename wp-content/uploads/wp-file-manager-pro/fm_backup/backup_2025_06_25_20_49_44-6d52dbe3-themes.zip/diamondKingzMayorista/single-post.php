<?php
get_header();

$ID = intval(get_the_ID());

?>



<?php get_footer(); ?>