<?php
/*
    Template name: content
*/

get_header();

?>

<section class="content">
    <div class="container">
        <div class="breadcrumb">
            <ol>
                <li>
                    <a href="<?php echo esc_url(home_url('/')) ?>"><?php wp_translate('Lar', 'Home', 'Inicio'); ?></a>
                </li>
                <li>/</li>
                <li><?php echo get_the_title(); ?></li>
            </ol>
        </div>
        <h1><?php echo get_the_title(); ?></h1>
        <div class="content_box">
            <?php the_content(); ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>