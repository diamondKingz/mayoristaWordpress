<?php
/*
    Template name: promos
*/

get_header();

?>

<section class="promotion">
    <div class="container">
        <div class="breadcrumb">
            <ol>
                <li>
                    <a href="<?php echo esc_url(home_url('/')) ?>"><?php wp_translate('Lar', 'Home', 'Inicio'); ?></a>
                </li>
                <li>/</li>
                <li><?php echo get_the_title(); ?></li>
            </ol>
        </div>
        <h1><?php wp_translate('Nossas ações', 'Our actions', 'Nuestras acciones'); ?></h1>
        
        <?php if (have_rows('promos')): ?>
            <div class="promotion_grid">
                <?php while (have_rows('promos')): the_row(); ?>

                    <?php if(!empty(get_sub_field('url_promo'))): ?>
                    <a href="<?php echo get_sub_field('url_promo') ?>" class="promo" target="_blank">
                    <?php else: ?>
                    <a class="promo">
                    <?php endif; ?>
                        <div class="promo-title">
                            <h2>
                                <?php echo get_sub_field('title_promo') ?? ''; ?>
                            </h2>
                        </div>
                        <div class="promo-image">
                            <img 
                                src="<?php echo get_sub_field('image_promo')['url'] ?>" 
                                title="<?php echo get_sub_field('image_promo')['title'] ?>" 
                                alt="<?php echo get_sub_field('image_promo')['alt'] ?>" 
                                width="<?php echo get_sub_field('image_promo')['width'] ?>" 
                                height="<?php echo get_sub_field('image_promo')['height'] ?>" 
                                loading="lazy"> 
                        </div>
                    </a>

                <?php endwhile; ?>
            </div>
        <?php endif; ?>

    </div>
</section>

<?php get_footer(); ?>