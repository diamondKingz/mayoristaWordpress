<?php
/*
    Template name: faq
*/

get_header();

?>

<section class="faq">
    <div class="container">
        <div class="breadcrumb">
            <ol>
                <li>
                    <a href="<?php echo esc_url(home_url('/')) ?>"><?php wp_translate('Lar', 'Home', 'Inicio'); ?></a>
                </li>
                <li>/</li>
                <li><?php echo get_the_title(); ?></li>
            </ol>
        </div>
        <h1><?php echo get_the_title(); ?></h1>
        <div class="faq_container">
            <div class="faq_elements">
                <?php if (have_rows('faq')): ?>
                    <ul id="my-accordion" class="accordionjs faq_list">
                        <?php while (have_rows('faq')): the_row(); ?>
                            <li class="faq__item">
                                <div>
                                    <p><?php echo get_sub_field('question_faq'); ?></p>
                                </div>
                                <div>
                                    <p><?php echo get_sub_field('answer_faq'); ?></p>
                                </div>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php else: ?>
                    <p><?php wp_translate('Ainda não há perguntas frequentes.', 'There are no FAQs yet.', 'No hay preguntas frecuentes aún.') ?></p>
                <?php endif; ?>
            </div>
            <div class="faq_forms">
                <div class="faq__send-resume">
                    <div class="faq__icon-mail">
                        <svg class="svg__sendEmail">
                            <use xlink:href="#sendEmail"></use>
                        </svg>
                    </div>
                    <p>
                        <?php wp_translate("Não encontrou a resposta para sua pergunta?", "Didn't find an answer to your question?", "¿No encontraste respuesta a tu pregunta?"); ?>
                        <br>
                        <?php wp_translate('Escreva para nós!', 'Write to us!', '¡Escríbenos!'); ?>
                    </p>
                    <button type="button" title="<?php wp_translate('Faça uma pergunta', 'Ask a question', 'Haz una pregunta'); ?>" class="toggle_popup" data-id="popup_form"><?php wp_translate('Faça uma pergunta', 'Ask a question', 'Haz una pregunta'); ?></button>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>

<script>
    jQuery(document).ready(function($) {
        $("#my-accordion").accordionjs({
            closeAble: true,
            closeOther: true,
            slideSpeed: 150,
            activeIndex: 100,
            openSection: function(section) {},
            beforeOpenSection: function(section) {},
        });
    });
</script>