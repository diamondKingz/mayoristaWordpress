<?php
/*
    Template name: about
*/

get_header();

?>

<section class="about">
    <div class="container">
        <div class="breadcrumb">
            <ol>
                <li>
                    <a href="<?php echo esc_url(home_url('/')) ?>"><?php wp_translate('Lar', 'Home', 'Inicio'); ?></a>
                </li>
                <li>/</li>
                <li><?php echo get_the_title(); ?></li>
            </ol>
        </div>
        <h1><?php echo get_the_title(); ?></h1>
        <div class="about-company">

            <?php if(have_rows('item_about')): ?>
                <?php while(have_rows('item_about')): the_row(); ?>
                <div class="about-company__item">
                    <div class="about-company__shadow">
                        <div class="about-company__text">
                            <h2><?php echo get_sub_field('title_about'); ?></h2>
                            <p><?php echo get_sub_field('description_about'); ?></p>
                            
                            <?php if(!empty(get_sub_field('link_about'))): ?>
                            <div class="about-company__link">
                                <a href="<?php echo get_sub_field('link_about')['url']; ?>">
                                    <?php echo get_sub_field('link_about')['title']; ?>
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="about-company__img">
                        <img 
                            src="<?php echo get_sub_field('image_about')['url'] ?>" 
                            title="<?php echo get_sub_field('image_about')['title'] ?>" 
                            alt="<?php echo get_sub_field('image_about')['alt'] ?>" 
                            width="<?php echo get_sub_field('image_about')['width'] ?>" 
                            height="<?php echo get_sub_field('image_about')['height'] ?>" 
                            loading="lazy"> 
                    </div>
                </div>
                <?php endwhile; ?>
            <?php endif; ?>

        </div>
    </div>
</section>

<?php get_footer(); ?>