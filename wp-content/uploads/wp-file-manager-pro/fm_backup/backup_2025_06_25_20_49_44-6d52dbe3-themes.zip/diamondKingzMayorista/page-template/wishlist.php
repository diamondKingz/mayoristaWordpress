<?php
/*
    Template name: wishlist
*/

get_header();

?>

<section class="cart">
    <div class="container">
        <div class="cart_heading w-100">
            <h1><?php wp_translate('Cesta', 'Basket', 'Cesta'); ?></h1>
        </div>
    </div>
    <?php echo do_shortcode('[yith_wcwl_wishlist]'); ?>
</section>

<?php get_footer(); ?>