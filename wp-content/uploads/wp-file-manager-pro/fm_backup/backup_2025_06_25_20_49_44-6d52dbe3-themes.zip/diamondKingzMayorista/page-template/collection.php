<?php
/*
    Template name: collection
*/

get_header();

$collections = get_terms(array(
    'taxonomy'   => 'product_collection',
    'hide_empty' => false,
));

?>

<section class="collection">
    <div class="container">
        <div class="breadcrumb">
            <ol>
                <li>
                    <a href="<?php echo esc_url(home_url('/')) ?>"><?php wp_translate('Lar', 'Home', 'Inicio'); ?></a>
                </li>
                <li>/</li>
                <li><?php echo get_the_title(); ?></li>
            </ol>
        </div>
        <h1><?php echo get_the_title(); ?></h1>

        <?php if (!empty($collections) && !is_wp_error($collections)): ?>
            <div class="collection_grid">
                <?php foreach ($collections as $collection): ?>
                    <a href="<?php echo get_term_link($collection); ?>" class="collection_item">
                        <div class="collection_item-title">
                            <h2><?php echo esc_html($collection->name); ?></h2>
                        </div>
                        <div class="collection_item-image">
                            <?php
                            $image = get_field('image_placeholder', 'product_collection_' . $collection->term_id);
                            if ($image): ?>
                                <img
                                    src="<?php echo esc_url($image['url']); ?>"
                                    title="<?php echo esc_attr($image['title']); ?>"
                                    alt="<?php echo esc_attr($image['alt']); ?>"
                                    width="<?php echo esc_attr($image['width']); ?>"
                                    height="<?php echo esc_attr($image['height']); ?>"
                                    loading="lazy">
                            <?php else: ?>
                                <img
                                    src="<?php echo esc_url(get_template_directory_uri() . '/assets/default-image.jpg'); ?>"
                                    alt="Default Image"
                                    width="300"
                                    height="300"
                                    loading="lazy">
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="w-100">
                <p><?php wp_translate('Ainda não há coleções criadas.', 'There are no collections created yet.', 'No hay colecciones creadas aún.'); ?></p>
            </div>
        <?php endif; ?>

    </div>
</section>

<?php get_footer(); ?>