<?php
/*
    Template name: home
*/

get_header();
?>

<main>
    <section class="section__slider">
        <div class="container">
            <div class="splide" id="hero">
                <div class="splide__track">
                    <ul class="splide__list">
                        <li class="splide__slide">
                            <img src="<?php echo IMG; ?>/3.webp">
                        </li>
                        <li class="splide__slide">
                            <img src="<?php echo IMG; ?>/4.webp">
                        </li>
                        <li class="splide__slide">
                            <img src="<?php echo IMG; ?>/5.webp">
                        </li>
                    </ul>
                </div>
                <div class="splide__bottom">
                    <ul class="splide__pagination"></ul>
                    <div class="splide__arrows"></div>
                </div>
            </div>
        </div>
    </section>
    <?php get_template_part('inc/sections/sec_decorations'); ?>
    <?php get_template_part('inc/sections/sec_news'); ?>
    <?php get_template_part('inc/sections/sec_collections'); ?>
    <?php get_template_part('inc/sections/sec_hits'); ?>
</main>

<?php get_footer(); ?>