import { Splide } from "@splidejs/splide";
// import { AutoScroll } from "@splidejs/splide-extension-auto-scroll";
import "@splidejs/splide/css";

(function(){

    if(document.querySelector('#hero')){
        new Splide('#hero', {
            type: 'loop',
            autoplay: true,
            interval: 4000,
            arrows: true,
            pagination: true,
            perPage: 1,
            breakpoints: {
            }
        }).mount();
    }

    if(document.querySelector('#decorations')){
        new Splide('#decorations', {
            type: 'loop',
            arrows: true,
            pagination: true,
            perPage: 4,
            perMove: 1,
            gap: '1.25rem',
            breakpoints: {
                1100: {
                    perPage: 3,
                },
                992: {
                    perPage: 2,
                },
                480: {
                    perPage: 1,
                }
            }
        }).mount();
    }

    if(document.querySelector('#collections')){
        new Splide('#collections', {
            type: 'loop',
            arrows: true,
            pagination: true,
            perPage: 3,
            perMove: 1,
            gap: '1.25rem',
            breakpoints: {
                992: {
                    perPage: 2,
                },
                480: {
                    perPage: 1,
                }
            }
        }).mount();
    }

    let perPage = ['#news', '#hits'];
    Array.from(perPage).forEach(slider=>{
        if(document.querySelector(slider)){
            new Splide(slider, {
                type: 'loop',
                arrows: true,
                pagination: true,
                perPage: 5,
                perMove: 1,
                gap: '.75rem',
                breakpoints: {
                    1350: {
                        perPage: 4
                    },
                    1100: {
                        perPage: 3
                    },
                    992: {
                        perPage: 2,
                    },
                    480: {
                        perPage: 1,
                    }
                }
            }).mount();
        }
    })

    if(document.querySelector('#gallery')){
        new Splide('#gallery', {
            type: 'loop',
            pagination: false,
            arrows: true,
            perPage: 1,
            perMove: 1,
            breakpoints: {
            }
        }).mount();
    }

})();