import './script.js';
import './sliders.js';
import './popup.js';