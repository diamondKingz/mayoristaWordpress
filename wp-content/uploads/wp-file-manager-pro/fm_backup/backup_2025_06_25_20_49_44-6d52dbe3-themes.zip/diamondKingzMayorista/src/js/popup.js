(function(){

    let toggle_popup = document.querySelectorAll('.toggle_popup');
    let popup = '';

    Array.from(toggle_popup).forEach(toggle=>{
        toggle.addEventListener('click', (e)=>{
            e.preventDefault();
            popup = e.currentTarget.getAttribute('data-id') ?? '';
            
            if(popup == ''){
                popup = e.currentTarget.closest('.popup')
                if(popup.classList.contains('active')){
                    popup.classList.remove('active');
                }
                return
            }
            
            document.querySelector(`#${popup}`).classList.toggle('active');
        })
    })

})();