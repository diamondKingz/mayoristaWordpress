(function(){

    let toggle_menu = document.querySelectorAll('.toggle_menu'),
        menu = document.querySelector('.headerBox');

    if(toggle_menu){
        Array.from(toggle_menu).forEach(menuButton => {
            menuButton.addEventListener('click', (e)=>{
                e.preventDefault();
                menu.classList.toggle('active');
            })
        })
    }

    // ----------------------------------
    // ----------------------------------
    // ----------------------------------

    document.addEventListener('DOMContentLoaded', function () {
        const wrapper = document.querySelector('.catalog-sub-menu__wrapper');
        const links = document.querySelectorAll('.catalog-sub-menu__item a[data-id]');
        const images = document.querySelectorAll('.catalog-sub-menu__image img');
    
        links.forEach(link => {
            link.addEventListener('mouseenter', () => {
                const id = link.getAttribute('data-id');
                wrapper.setAttribute('data-state', id);
    
                // Mostrar solo la imagen con el data-id correspondiente
                images.forEach(img => {
                    img.style.display = img.getAttribute('data-id') === id ? 'block' : 'none';
                });
    
                // Agregar clase 'active' al enlace actual y remover de los demás
                links.forEach(l => l.classList.remove('active'));
                link.classList.add('active');
            });
        });
    });        

})();