<?php
// Creamos la función para el post type service
function custom_post_service() {
    // Registramos la función 'service' según el codex de WP
    register_post_type( 'service',
      array( 'labels' => array(
        'name' => __( 'Services', 'andres-dev' ),
        'singular_name' => __( 'Service', 'andres-dev' ),
        'all_items' => __( 'All services', 'andres-dev' ),
        'add_new' => __( 'Add new', 'andres-dev' ),
        'add_new_item' => __( 'Add new service', 'andres-dev' ),
        'edit' => __( 'Edit', 'andres-dev' ),
        'edit_item' => __( 'Edit service', 'andres-dev' ),
        'new_item' => __( 'New service', 'andres-dev' ),
        'view_item' => __( 'View service', 'andres-dev' ),
        'search_items' => __( 'Search service', 'andres-dev' ),
        'not_found' => __( 'No results found', 'andres-dev' ),
        'not_found_in_trash' => __( 'Nothing found in trash', 'andres-dev' ),
        ),
        'description' => __( 'This is a custom post type for services', 'andres-dev' ),
        'public' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'show_ui' => true,
        'query_var' => true,
        'menu_position' => 8,
        'menu_icon' => 'dashicons-businessman', // Cambia el icono si lo deseas
        'rewrite' => array( 'slug' => 'service', 'with_front' => false ),
        'has_archive' => 'service',
        'capability_type' => 'post',
        'hierarchical' => false,
        'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky')
      )
    );
}
add_action( 'init', 'custom_post_service');

// Creamos la taxonomía service_category para services
add_action( 'init', 'create_service_taxonomy' );
function create_service_taxonomy() {
  register_taxonomy(
    'service_category',
    'service',
    array(
      'label' => __( 'Service Category', 'andres-dev' ),
      'rewrite' => array( 'slug' => 'service-category' ),
      'hierarchical' => true,
    )
  );
}

// Creamos taxonomía tags para services
add_action( 'init', 'create_service_taxonomy_tags' );
function create_service_taxonomy_tags() {
  register_taxonomy(
    'service_tag',
    'service',
    array(
      'rewrite' => array( 'slug' => 'service-tag' ),
      'hierarchical' => false,
      'update_count_callback' => '_update_post_term_count',
    )
  );
}

// Agrega soporte para categorías y tags a 'service'
register_taxonomy_for_object_type( 'category', 'service' );
register_taxonomy_for_object_type( 'post_tag', 'service' );
?>
