<?php
$args = array(
    'post_type'      => 'product',
    'post_status'    => 'publish',
    'posts_per_page' => 10,
    'orderby'        => 'date',
    'order'          => 'DESC',
);

$query = new WP_Query($args);
?>

<?php if ($query->have_posts()) : ?>
    <section class="section__inhome section__news">
        <div class="container">
            <div class="heading">
                <h2><?php wp_translate('Os sucessos da temporada', 'The hits of the season', 'Los hits de la temporada'); ?></h2>

                <?php if (LANG == 'pt-BR'): ?>
                    <a href="<?php echo esc_url(home_url('pt/catalogo-2/')) ?>" title="Todos os sucessos">Todos os sucessos</a>
                <?php elseif (LANG == 'en-US'): ?>
                    <a href="<?php echo esc_url(home_url('catalog')) ?>" title="All successes">All successes</a>
                <?php else: ?>
                    <a href="<?php echo esc_url(home_url('es/catalogo')) ?>" title="Todos los éxitos">Todos los éxitos</a>
                <?php endif; ?>
            </div>
            <div class="splide" id="hits">
                <div class="splide__track">
                    <ul class="splide__list">
                        <?php
                        while ($query->have_posts()) {
                            $query->the_post();
                            echo '<li class="splide__slide">';
                            get_card_product(get_the_ID());
                            echo '</li>';
                        }
                        wp_reset_postdata();
                        wp_reset_query();
                        ?>
                    </ul>
                </div>
                <div class="splide__bottom">
                    <ul class="splide__pagination"></ul>
                    <div class="splide__arrows"></div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>