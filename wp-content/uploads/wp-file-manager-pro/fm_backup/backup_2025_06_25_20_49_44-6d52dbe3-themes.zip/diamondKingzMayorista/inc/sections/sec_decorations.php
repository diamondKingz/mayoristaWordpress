<?php
$categories = get_terms(array(
    'taxonomy'   => 'product_cat',
    'hide_empty' => false,
));
?>

<?php if (!empty($categories) && !is_wp_error($categories)): ?>
    <section class="section__inhome section__decorations">
        <div class="container">
            <div class="heading">
                <h2><?php wp_translate('A decoração', 'The decoration', 'La decoración'); ?></h2>

                <?php if (LANG == 'pt-BR'): ?>
                    <a href="<?php echo esc_url(home_url('pt/catalogo-2/')) ?>" title="O catálogo inteiro">O catálogo inteiro</a>
                <?php elseif (LANG == 'en-US'): ?>
                    <a href="<?php echo esc_url(home_url('catalog')) ?>" title="The entire catalog">The entire catalog</a>
                <?php else: ?>
                    <a href="<?php echo esc_url(home_url('es/catalogo')) ?>" title="Todo el catálogo">Todo el catálogo</a>
                <?php endif; ?>
            </div>
            <div class="splide" id="decorations">
                <div class="splide__track">
                    <ul class="splide__list">
                        <?php
                        foreach ($categories as $category):
                            $thumbnail_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                            $image_url = $thumbnail_id ? wp_get_attachment_url($thumbnail_id) : wc_placeholder_img_src();
                        ?>
                            <li class="splide__slide">
                                <a href="<?php echo esc_url(get_term_link($category)); ?>" class="promo">
                                    <div class="promo-title">
                                        <h2><?php echo esc_html($category->name); ?></h2>
                                    </div>
                                    <div class="promo-image">
                                        <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($category->name); ?>" loading="lazy">
                                    </div>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="splide__bottom">
                    <ul class="splide__pagination"></ul>
                    <div class="splide__arrows"></div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php wp_reset_postdata();wp_reset_query(); ?>