<?php
$categories = get_terms(array(
    'taxonomy'   => 'product_cat',
    'hide_empty' => false,
));

$metals = get_terms([
    'taxonomy' => 'product_metal',
    'hide_empty' => false,
]);

$for_whom = get_terms([
    'taxonomy' => 'product_for_whom',
    'hide_empty' => false,
]);
?>

<div class="catalog-sub-menu">
    <div class="container">
        <?php if (!empty($categories) && !is_wp_error($categories)): ?>
            <div class="catalog-sub-menu__wrapper" data-state="<?php echo $categories[0]->term_id; ?>">
                <div class="catalog-sub-menu__item">
                    <div class="catalog-sub-menu__item-title">
                        <p><?php wp_translate('Decoração', 'Decorating', 'Decorando'); ?></p>
                    </div>
                    <?php if (LANG == 'pt-BR'): ?>
                        <a href="<?php echo esc_url(home_url('pt/catalogo-2/')) ?>" title="Todas as decorações">
                            <svg class="svg__catalogSubMenu">
                                <use xlink:href="#catalog-all"></use>
                            </svg>
                            Todas as decorações
                        </a>
                    <?php elseif (LANG == 'en-US'): ?>
                        <a href="<?php echo esc_url(home_url('catalog')) ?>" title="All decorations">
                            <svg class="svg__catalogSubMenu">
                                <use xlink:href="#catalog-all"></use>
                            </svg>
                            All decorations
                        </a>
                    <?php else: ?>
                        <a href="<?php echo esc_url(home_url('es/catalogo/')) ?>" title="Todas las decoraciones">
                            <svg class="svg__catalogSubMenu">
                                <use xlink:href="#catalog-all"></use>
                            </svg>
                            Todas las decoraciones
                        </a>
                    <?php endif; ?>

                    <?php foreach ($categories as $category): ?>
                        <a href="<?php echo esc_url(get_term_link($category)); ?>" data-id="<?php echo $category->term_id; ?>" title=" <?php echo esc_html($category->name); ?>">
                            <?php
                            $visual = get_field('icon_or_svg_cat', 'product_cat_' . $category->term_id);
                            if ($visual): ?>
                                <?php $icon = get_field('icon_category', 'product_cat_' . $category->term_id);
                                if (!empty($icon)): ?>
                                    <img src="<?php echo $icon['url']; ?>" title="<?php echo $icon['title']; ?>" alt="<?php echo $icon['alt']; ?>" height="<?php echo $icon['height']; ?>" width="<?php echo $icon['width']; ?>">
                                <?php endif; ?>
                            <?php else: ?>
                                <?php
                                $svg = get_field('svg_code_category', 'product_cat_' . $category->term_id);
                                if (!empty($svg)) {
                                    echo $svg;
                                }
                                ?>
                            <?php endif; ?>
                            <?php echo esc_html($category->name); ?>
                        </a>
                    <?php endforeach; ?>
                </div>

                <div class="catalog-sub-menu__submenu">
                    <?php if (!empty($metals) && !is_wp_error($metals)): ?>
                        <div class="catalog-sub-menu__item_content-list catalog-sub-menu__item">
                            <div class="catalog-sub-menu__item-title">
                                <p>Metal</p>
                            </div>
                            <?php foreach ($metals as $metal) : ?>
                                <a class="catalog-sub-menu__list" href="<?php echo get_term_link($metal); ?>" title="<?php echo esc_html($metal->name); ?>">
                                    <?php echo esc_html($metal->name); ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <!-- --------------------------------- -->
                    <?php if (!empty($for_whom) && !is_wp_error($for_whom)): ?>
                        <div class="catalog-sub-menu__item_content-list catalog-sub-menu__item">
                            <div class="catalog-sub-menu__item-title">
                                <p>For Whom</p>
                            </div>
                            <?php foreach ($for_whom as $for) : ?>
                                <a class="catalog-sub-menu__list" href="<?php echo get_term_link($for); ?>" title="<?php echo esc_html($for->name); ?>">
                                    <?php echo esc_html($for->name); ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="catalog-sub-menu__image">
                    <?php foreach ($categories as $category): ?>
                        <?php
                        $thumbnail_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                        $image_url = $thumbnail_id ? wp_get_attachment_url($thumbnail_id) : wc_placeholder_img_src();
                        ?>
                        <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($category->name); ?>" data-id="<?php echo $category->term_id; ?>">
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>