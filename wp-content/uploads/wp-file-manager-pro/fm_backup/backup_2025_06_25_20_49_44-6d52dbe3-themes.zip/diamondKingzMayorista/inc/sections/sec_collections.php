<?php
$collections = get_terms(array(
    'taxonomy'   => 'product_collection',
    'hide_empty' => false,
));
?>

<?php if (!empty($collections) && !is_wp_error($collections)): ?>
    <section class="section__inhome section__collection">
        <div class="container">
            <div class="heading">
                <h2><?php wp_translate('A coleção', 'The collection', 'La colección'); ?></h2>

                <?php if (LANG == 'pt-BR'): ?>
                    <a href="<?php echo esc_url(home_url('pt/a-colecao/')) ?>" title="Todas as coleções">Todas as coleções</a>
                <?php elseif (LANG == 'en-US'): ?>
                    <a href="<?php echo esc_url(home_url('the-collection')) ?>" title="All collections">All collections</a>
                <?php else: ?>
                    <a href="<?php echo esc_url(home_url('es/la-coleccion')) ?>" title="Todas las colecciones">Todas las colecciones</a>
                <?php endif; ?>
            </div>
            <div class="splide" id="collections">
                <div class="splide__track">
                    <ul class="splide__list">
                        <?php foreach ($collections as $collection): ?>
                            <li class="splide__slide">
                                <a href="<?php echo get_term_link($collection); ?>" class="collection_item">
                                    <div class="collection_item-title">
                                        <h2><?php echo esc_html($collection->name); ?></h2>
                                    </div>
                                    <div class="collection_item-image">
                                        <?php
                                        $image = get_field('image_placeholder', 'product_collection_' . $collection->term_id);
                                        if ($image): ?>
                                            <img
                                                src="<?php echo esc_url($image['url']); ?>"
                                                title="<?php echo esc_attr($image['title']); ?>"
                                                alt="<?php echo esc_attr($image['alt']); ?>"
                                                width="<?php echo esc_attr($image['width']); ?>"
                                                height="<?php echo esc_attr($image['height']); ?>"
                                                loading="lazy">
                                        <?php else: ?>
                                            <img
                                                src="<?php echo esc_url(get_template_directory_uri() . '/assets/default-image.jpg'); ?>"
                                                alt="Default Image"
                                                width="300"
                                                height="300"
                                                loading="lazy">
                                        <?php endif; ?>
                                    </div>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="splide__bottom">
                    <ul class="splide__pagination"></ul>
                    <div class="splide__arrows"></div>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>